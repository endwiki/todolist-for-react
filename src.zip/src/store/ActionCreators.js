import { CHANGE_INPUT_VALUE, ADD_VALUE_TO_LIST, DELETE_ITEM_IN_LIST,
  INIT_LIST_ITEM }
  from './ActionTypes'
import axios from 'axios';

export const getInputChangeAction = (value) => ({
    type: CHANGE_INPUT_VALUE,
    value
});

export const getPushItemAction = () => ({
    type: ADD_VALUE_TO_LIST,
});

export const getDeleteItemAction = (value) => ({
    type: DELETE_ITEM_IN_LIST,
    value
});

export const getInitListItemAction = (value) => ({
    type: INIT_LIST_ITEM,
    value
});

export const getTodoList = () => {
    return (dispatch) => {
      axios.get('/list.json').then((res) => {
        const data = res.data;
        const action = getInitListItemAction(data);
        dispatch(action);
      });
    }
}
