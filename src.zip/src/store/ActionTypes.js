export const CHANGE_INPUT_VALUE = 'change_input_value';
export const DELETE_ITEM_IN_LIST = 'delete_item_in_list';
export const ADD_VALUE_TO_LIST = 'add_value_to_list';
export const INIT_LIST_ITEM = 'init_list_item';
